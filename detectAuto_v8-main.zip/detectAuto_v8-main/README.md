# detectAuto_v8
yolov8自动标注
操作与v5自动标注相当，不需要导入.yaml文件   
python detect_auto.py
