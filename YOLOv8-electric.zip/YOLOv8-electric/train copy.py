from ultralytics import YOLO
 
model = YOLO("/home/ubuntu/SunMZ/yolov8n.pt")
 
data = "/home/ubuntu/SunMZ/YOLOv8-electric/ultralytics/cfg/datasets/SMZ.yaml"
 
model.train(
    data=data,
    epochs=200,
    batch=16,
    project='/home/ubuntu/SunMZ/YOLOv8-xysy/runs-SMZ/train',  # 设定你的保存路径目录
    name='exp'  # 子目录，你的实验的名字
)
